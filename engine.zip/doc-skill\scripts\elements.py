"""ELEMENTS.tsv -> elements/cut/NN.png  (direct 16:9 full-frame illustrations via the Gemini
Canvas 'Bulk Image Generator', not Google Flow)

Run inside the project folder (where ELEMENTS.tsv lives):
    python <skill>/scripts/elements.py                 # generate any missing 16:9 images, then process
    python <skill>/scripts/elements.py process          # re-process existing 04-images/<name> or elements/raw into elements/cut/
    python <skill>/scripts/elements.py --name <cap>     # use this cap-avatar 04-images folder name
    python <skill>/scripts/elements.py --extra "..."    # append a short note to every prompt

Visual engine: the Gemini Canvas app 'Bulk Image Generator', driven by the Playwright runner
    <GEMINI_ROOT>/tools/gemini/lib/batch.js   (default port 9223, logged-in Chrome profile).
The runner writes 04-images/<name>/<name>_NN.jpg, which we copy to elements/raw/ and
resize/center-crop to exact 1920x1080 PNG in elements/cut/ (no chroma key, no background colour).

Mandatory style -- written once to style.txt and applied to the whole batch via the tool's
STYLE-CONSISTENCY box, so every image prompt inherits it:
    hand-drawn 2D editorial illustration style with a vintage cartoon aesthetic, muted colors,
    and educational explainer visuals.

Env:
    GEMINI_ROOT   the cap-avatar-full folder (default D:\\cap-avatar-BOTH\\cap-avatar-full)
    GEMINI_PORT   remote-debugging port of the logged-in Chrome (default 9223)
    GEMINI_ASPECT aspect ratio passed to the runner (default 16:9)
"""
import csv, glob, hashlib, os, re, shutil, subprocess, sys
from PIL import Image

GEMINI_ROOT = os.environ.get("GEMINI_ROOT", r"D:\cap-avatar-BOTH\cap-avatar-full")
PORT = os.environ.get("GEMINI_PORT", "9223")
ASPECT = os.environ.get("GEMINI_ASPECT", "16:9")

STYLE = ("hand-drawn 2D editorial illustration style with a vintage cartoon aesthetic, "
         "muted colors, and educational explainer visuals.")

RAW, CUT = "elements/raw", "elements/cut"
W, H = 1920, 1080


def _arg(name, default=None):
    if "--" + name in sys.argv:
        i = sys.argv.index("--" + name)
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return default


NAME = _arg("name") or re.sub(r"[^A-Za-z0-9_-]+", "_", os.path.basename(os.getcwd())).strip("_").lower() or "batch"
EXTRA = _arg("extra", "").strip()


def cap_dir():
    return os.path.join(GEMINI_ROOT, "04-images", NAME)


def rows():
    with open("ELEMENTS.tsv", encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter="\t"))


def write_inputs():
    """Write prompts.txt (one object per line) and style.txt into the cap-avatar folder."""
    d = cap_dir()
    os.makedirs(d, exist_ok=True)
    prompts = []
    for r in rows():
        p = r["object"].strip()
        if EXTRA:
            p = f"{p}. {EXTRA}"
        prompts.append(p)
    with open(os.path.join(d, "prompts.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(prompts) + "\n")
    with open(os.path.join(d, "style.txt"), "w", encoding="utf-8") as f:
        f.write(STYLE + "\n")
    return len(prompts)


def generate():
    n = write_inputs()
    print(f"[gemini] {n} prompts + style written to {cap_dir()}")
    batch = os.path.join(GEMINI_ROOT, "tools", "gemini", "lib", "batch.js")
    if not os.path.exists(batch):
        print(f"[gemini] batch.js not found at {batch} -- is GEMINI_ROOT correct?")
        return False
    cmd = ["node", batch,
           "--prompts", f"04-images/{NAME}/prompts.txt",
           "--style", f"04-images/{NAME}/style.txt",
           "--name", NAME, "--aspect", ASPECT, "--port", PORT]
    print(f"[gemini] running: cd /d {GEMINI_ROOT} && node tools/gemini/lib/batch.js "
          f"--prompts 04-images/{NAME}/prompts.txt --style 04-images/{NAME}/style.txt "
          f"--name {NAME} --aspect {ASPECT} --port {PORT}")
    r = subprocess.run(cmd, cwd=GEMINI_ROOT)
    if r.returncode != 0:
        print(f"[gemini] batch.js exited {r.returncode} -- make sure the logged-in Chrome "
              f"profile is reachable on port {PORT} (see the cap-avatar browser folder).")
        return False
    print(f"[gemini] images in {cap_dir()}")
    return True


def dupes():
    """Same image under two names (a batch mispair) is a byte-for-byte duplicate -- refuse it."""
    seen = {}
    for p in sorted(glob.glob(os.path.join(RAW, "*"))):
        h = hashlib.md5(open(p, "rb").read()).hexdigest()
        seen.setdefault(h, []).append(os.path.basename(p))
    return [v for v in seen.values() if len(v) > 1]


def _to_1080(src):
    """Direct 16:9 full frame: resize, or center-crop to a 16:9 box, then to exact 1920x1080."""
    im = Image.open(src).convert("RGB")
    w, h = im.size
    if (w, h) != (W, H):
        if abs(w / h - 16 / 9) < 0.05:
            im = im.resize((W, H), Image.LANCZOS)
        else:
            tw = round(h * 16 / 9)
            if tw <= w:
                left = (w - tw) // 2
                im = im.crop((left, 0, left + tw, h)).resize((W, H), Image.LANCZOS)
            else:
                th = round(w * 9 / 16)
                top = (h - th) // 2
                im = im.crop((0, top, w, top + th)).resize((W, H), Image.LANCZOS)
    return im


def harvest():
    """Copy <name>_NN.jpg out of the cap-avatar folder into elements/raw (sequential, keep existing)."""
    os.makedirs(RAW, exist_ok=True)
    files = sorted(glob.glob(os.path.join(cap_dir(), f"{NAME}_*")))
    for i, src in enumerate(files, start=1):
        dst = os.path.join(RAW, f"{i:02d}{os.path.splitext(src)[1]}")
        if not os.path.exists(dst):
            shutil.copy2(src, dst)
    print(f"[gemini] harvested {len(glob.glob(os.path.join(RAW, '*')))} raw images into {RAW}/")


def process():
    d = dupes()
    assert not d, f"same image under different prompts (batch mispair): {d}"
    os.makedirs(CUT, exist_ok=True)
    n = 0
    for r in rows():
        hits = glob.glob(f"{RAW}/{r['id']}.*")
        if not hits:
            continue
        _to_1080(hits[0]).save(f"{CUT}/{r['id']}.png", "PNG")
        n += 1
    got = glob.glob(f"{CUT}/*.png")
    print(f"direct 16:9 full frame images ready: {len(got)} in {CUT}/ ({n} processed now)")


def key():
    """Alias for backwards compatibility -- chroma key removed for direct 16:9 images."""
    print("Direct 16:9 full frame mode: saving Gemini images directly (no chroma key).")
    process()


if __name__ == "__main__":
    sub = [a for a in sys.argv[1:] if not a.startswith("--")]
    need_gen = "process" not in sub and "key" not in sub
    if need_gen:
        missing = [r for r in rows() if not glob.glob(f"{CUT}/{r['id']}.png")]
        if missing:
            print(f"[gemini] {len(missing)} images missing -> generating via Gemini Canvas")
            if generate():
                harvest()
        else:
            print("[gemini] all images already in elements/cut/ -> skipping generation")
    process()
