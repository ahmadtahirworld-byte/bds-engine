# -*- coding: utf-8 -*-
"""Direct 16:9 full-frame image processor (chroma-key removed).

Converts/copies raw Flow generations directly to 16:9 full-frame 1920x1080 PNGs
without purplish background or chroma-keying.

usage:  python key.py <src_dir> <dst_dir>
        python key.py --demo
"""
import glob, os, sys
import numpy as np
from PIL import Image

KEY_HI = 40.0
KEY_LO = -15.0


def magentaness(a):
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    return np.minimum(r, b) - g


def extract(src, pad=0):
    """Direct 16:9 full-frame image processor - no chroma key."""
    im = Image.open(src).convert("RGB")
    w, h = im.size
    if (w, h) != (1920, 1080):
        if abs(w / h - 16 / 9) < 0.05:
            im = im.resize((1920, 1080), Image.LANCZOS)
        else:
            target_w = round(h * 16 / 9)
            if target_w <= w:
                left = (w - target_w) // 2
                im = im.crop((left, 0, left + target_w, h)).resize((1920, 1080), Image.LANCZOS)
            else:
                target_h = round(w * 9 / 16)
                top = (h - target_h) // 2
                im = im.crop((0, top, w, top + target_h)).resize((1920, 1080), Image.LANCZOS)
    return im.convert("RGBA"), "direct_16_9"


def key(src, pad=0, crop=False):
    img, _ = extract(src, pad=pad)
    return img


def coverage(p):
    """Fraction of the frame that is solid - sanity check."""
    a = np.asarray(Image.open(p).convert("RGBA"))[..., 3]
    return float((a > 128).mean())


def bleed(src):
    """Direct mode: bleed check is not applicable."""
    return 0.0


def demo():
    im = Image.new("RGB", (1920, 1080), (241, 233, 216))
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_keydemo.png")
    im.save(p)
    out, how = extract(p)
    assert out.size == (1920, 1080)
    os.remove(p)
    print("key demo OK - direct 16:9 full-frame image processed (no chroma key)")


if __name__ == "__main__":
    if "--demo" in sys.argv:
        demo(); raise SystemExit
    if "--qc" in sys.argv:
        print("Direct 16:9 mode: chroma key QC check skipped.")
        raise SystemExit
    src, dst = sys.argv[1], sys.argv[2]
    os.makedirs(dst, exist_ok=True)
    for f in sorted(glob.glob(os.path.join(src, "*.jpg")) + glob.glob(os.path.join(src, "*.png"))):
        o = os.path.join(dst, os.path.splitext(os.path.basename(f))[0] + ".png")
        img, how = extract(f)
        img.save(o)
        print("%-12s %-44s direct 16:9" % (how, os.path.basename(o)[:44]), flush=True)
