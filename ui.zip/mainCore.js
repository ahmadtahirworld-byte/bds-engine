// Business Doc Studio -- the app core (updatable through the git UI channel).
//
// main.js (the thin bootstrap, baked into the installer once and never changed
// again) loads this file from the writable mirror DATA\ui\ when a UI update has
// ever been applied, and otherwise from the copy shipped inside the installer.
// Everything this core touches (index.html, preload.js, baked.js, update.js,
// license_public.pem, the icons) resolves relative to ITS OWN directory, so a
// UI update swaps the entire set at once. The heavy engine (python, ffmpeg,
// node, models, the backend bundle) stays in the installer and is updated
// separately through the engine.zip channel.
const { app, BrowserWindow, ipcMain, shell, net } = require('electron');
const crypto = require('crypto');   // Node's crypto (RSA key verification) -- NOT an electron export
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');

function start() {

// Path roots. The bootstrap (main.js, always the installed copy) tells us, via
// env vars, where the INSTALLED resources live -- because when this core runs
// from the writable UI mirror (DATA\ui) its own __dirname is the mirror, not
// the app directory, and the backend/pipeline must still point at the
// installer's resources. Fallbacks keep dev (npm start) working.
const RES = app.isPackaged ? process.resourcesPath : path.join(__dirname, '..');
const BUNDLE_PIPELINE = process.env.BDS_PIPELINE
  || (app.isPackaged ? path.join(RES, 'pipeline.py') : path.join(__dirname, '..', 'pipeline.py'));
const BACKEND_ROOT = process.env.BDS_BACKEND
  || (app.isPackaged ? path.join(RES, 'backend') : path.join(__dirname, '..', 'backend'));
const ICON = path.join(__dirname, 'icon.ico');
// baked.js holds the encrypted Claude-key blob. It ships inside the installer
// but deliberately does NOT travel the public git ui channel -- a public repo
// should not carry decryptable key material. When this core runs from the
// writable mirror, use the installer's copy (in app.asar when packaged).
const BAKED_CANDIDATES = [
  path.join(__dirname, 'baked.js'),
  ...(app.isPackaged ? [path.join(process.resourcesPath, 'app.asar', 'baked.js')] : []),
];
function bakedFile() {
  for (const f of BAKED_CANDIDATES) { try { if (fs.existsSync(f)) return f; } catch {} }
  return BAKED_CANDIDATES[0];
}

// (BACKEND_ROOT is derived above from the bootstrap env or the app dir)

// Everything the pipeline or the Gemini runner WRITES (project folders, generated
// images, the browser login profile) goes under DATA, a writable user folder. The
// bundle itself may live in a read-only place (Program Files); only its CODE and
// MODELS are read from there.
const DATA = process.env.BUSINESS_DOC_WORKDIR ||
  path.join(process.env.USERPROFILE || os.homedir(), 'BusinessDoc');

const isWin = process.platform === 'win32';
function bundlePaths() {
  return {
    backend: BACKEND_ROOT,
    python: path.join(BACKEND_ROOT, 'python', isWin ? 'python.exe' : 'python3'),
    ffmpeg: path.join(BACKEND_ROOT, 'ffmpeg'),
    node: path.join(BACKEND_ROOT, 'node'),
    nodeExe: path.join(BACKEND_ROOT, 'node', isWin ? 'node.exe' : 'node'),
    geminiSrc: path.join(BACKEND_ROOT, 'gemini'),          // bundled (read-only) runner
    geminiRoot: path.join(DATA, 'gemini'),            // writable mirror of the runner
    hfCache: path.join(BACKEND_ROOT, 'cache', 'huggingface', 'hub'),
    // bundle copies are the FALLBACK; the engine mirror (writable, updatable) wins
    docSkill: path.join(BACKEND_ROOT, 'doc-skill'),
    voxSkill: path.join(BACKEND_ROOT, 'vox-skill'),
  };
}

// Writable, updatable engine mirror (pipeline.py + skill scripts + junctioned assets).
// Built at startup; an in-app update only ever rewrites files in here, never the
// read-only bundle, so a fix ships as a ~150 KB zip instead of a 1 GB installer.
const engineMod = require('./update.js')({
  DATA, BACKEND_ROOT, PIPELINE: BUNDLE_PIPELINE,
  python: path.join(BACKEND_ROOT, 'python', isWin ? 'python.exe' : 'python3'),
});
function enginePaths() {
  const P = bundlePaths();
  const E = engineMod.enginePaths();
  // only redirect to the mirror when the mirrored files actually exist;
  // otherwise fall back to the read-only bundle copy
  P.docSkill = fs.existsSync(path.join(E.docSkill, 'scripts')) ? E.docSkill : P.docSkill;
  P.voxSkill = fs.existsSync(path.join(E.voxSkill, 'scripts')) ? E.voxSkill : P.voxSkill;
  P.pipeline = fs.existsSync(E.pipeline) ? E.pipeline : BUNDLE_PIPELINE;
  return P;
}

// Mirror the Gemini runner (code + node_modules + .env) into the writable data
// root so 04-images/ and the browser login profile can be written even when the
// app is installed to a read-only folder. Copies only when it's missing.
function ensureGeminiMirror() {
  const P = bundlePaths();
  const marker = path.join(P.geminiRoot, 'tools', 'gemini', 'lib', 'batch.js');
  if (!fs.existsSync(marker)) {
    fs.mkdirSync(P.geminiRoot, { recursive: true });
    fs.cpSync(P.geminiSrc, P.geminiRoot, { recursive: true });
  }
  return P;
}

// Env shared by the pipeline and the Gemini runner: points the whole engine at the
// bundled python / ffmpeg / node / models / whisper cache, and injects the Claude
// key (never shown in the UI).
function pipelineEnv() {
  const P = enginePaths();
  const extraPath = [P.ffmpeg, P.node, process.env.PATH || ''].join(path.delimiter);
  return Object.assign({}, process.env, {
    PATH: extraPath,
    DOC_SKILL: P.docSkill,
    VOX_SKILL: P.voxSkill,
    GEMINI_ROOT: P.geminiRoot,
    GEMINI_PORT: process.env.GEMINI_PORT || '9223',
    HUGGINGFACE_HUB_CACHE: P.hfCache,
    HF_HOME: path.dirname(P.hfCache),
    HF_HUB_OFFLINE: '1',
    TRANSFORMERS_OFFLINE: '1',
    ANTHROPIC_API_KEY: claudeKey(),
    ANTHROPIC_BASE_URL: claudeBase() || undefined,
  });
}
// license key is stored per-user, in the app's userData folder (resolved lazily
// so it is safe before or after app-ready)
function licFile() {
  const dir = app.isReady ? app.getPath('userData')
    : path.join(os.homedir(), '.BusinessDocStudio');
  return path.join(dir, 'license.key');
}

// RSA PUBLIC key only, copied next to the app at build time. The app can VERIFY
// owner-minted keys but can never CREATE one -- the private key lives in the
// owner's tools/ folder and is excluded from the installer.
const PUB_KEY_FILE = path.join(__dirname, 'license_public.pem');

let win = null;
let job = null;

// This installer ships UI v1. Stamp the writable mirror so the updater tracks
// versions from here; a later ui.zip update overwrites both the files and the
// stamp. (If the stamp number is ever bumped for a new installer, bump here too.)
const BUNDLED_UI_VERSION = 1;
function ensureUiStamp() {
  try {
    const uv = path.join(DATA, 'ui', 'version.txt');
    if (!fs.existsSync(uv)) {
      fs.mkdirSync(path.dirname(uv), { recursive: true });
      fs.writeFileSync(uv, String(BUNDLED_UI_VERSION));
    }
  } catch {}
}

function emit(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}

// ----------------------------------------------------------- license (RSA)
function verifyKey(keyText) {
  try {
    const pubPem = fs.readFileSync(PUB_KEY_FILE, 'utf8');
    const parts = String(keyText).trim().split('-');
    if (parts.length !== 3 || parts[0] !== 'BD') return { ok: false, why: 'not a valid key format' };
    const payload = Buffer.from(parts[1], 'base64');
    const sig = Buffer.from(parts[2], 'base64');
    const okSig = crypto.verify('RSA-SHA256', payload, pubPem, sig);
    if (!okSig) return { ok: false, why: 'signature does not match this app' };
    const data = JSON.parse(payload.toString('utf8'));
    if (Date.now() / 1000 > (data.e || 0)) return { ok: false, why: 'license has expired' };
    return { ok: true, user: data.u || '', note: data.n || '', exp: data.e };
  } catch (e) {
    return { ok: false, why: String(e.message || e) };
  }
}

function storedLicense() {
  try { return fs.readFileSync(licFile(), 'utf8').trim(); } catch { return ''; }
}
function saveLicense(k) { try { fs.mkdirSync(path.dirname(licFile()), { recursive: true }); fs.writeFileSync(licFile(), k); } catch {} }

function licenseState() {
  const k = storedLicense();
  if (!k) return { licensed: false };
  const v = verifyKey(k);
  return v.ok ? { licensed: true, user: v.user, note: v.note, exp: v.exp }
              : { licensed: false, stale: true };
}

// ----------------------------------------------------------- hidden Claude key
// Resolution order: a key the USER saved on this PC (DATA/api.key) wins, then the
// built-in baked key. This lets the owner run the app with their own Anthropic key.
// The baked blob may be a plain key string (legacy) or a JSON object
// {"k": "<key>", "b": "<base url or empty>"} so a gateway base URL can travel
// with the key (ClaudeMax & co keys don't work against api.anthropic.com).
function decryptClaudeBlob() {
  try {
    const blob = require(bakedFile());
    const key = Buffer.from(blob.k, 'base64');
    const iv = Buffer.from(blob.iv, 'base64');
    const dec = crypto.createDecipheriv('aes-256-cbc', key, iv);
    // Node auto-strips PKCS7 padding on final(); do NOT slice manually.
    const out = Buffer.concat([dec.update(Buffer.from(blob.d, 'base64')), dec.final()]);
    const text = out.toString('utf8');
    if (text.startsWith('{')) {
      try {
        const o = JSON.parse(text);
        // blob may be written as {k,b} (current baker) or {key,base} (defensive)
        return { key: o.k || o.key || '', base: o.b || o.base || '' };
      } catch { /* fall through to legacy plain-string */ }
    }
    return { key: text, base: '' };
  } catch { return { key: process.env.ANTHROPIC_API_KEY || '', base: process.env.ANTHROPIC_BASE_URL || '' }; }
}

function customKey() {
  try { return fs.readFileSync(path.join(DATA, 'api.key'), 'utf8').trim(); } catch { return ''; }
}
function claudeKey() { return customKey() || decryptClaudeBlob().key; }
// baked/ambient base URL: reseller gateways (sk-claudemax-*) need their own host
function claudeBase() { return decryptClaudeBlob().base || process.env.ANTHROPIC_BASE_URL || ''; }

function createWindow() {
  win = new BrowserWindow({
    width: 1080, height: 760, minWidth: 960, minHeight: 680,
    title: 'Business Doc Studio',
    icon: ICON,
    backgroundColor: '#0d0b10',
    webPreferences: {
      contextIsolation: true, nodeIntegration: false,
      // resolved relative to THIS file: the mirrored preload when the core came
      // from a UI update, the installed one otherwise
      preload: path.join(__dirname, 'preload.js')
    }
  });
  win.setMenu(null);
  win.loadFile(path.join(__dirname, 'index.html'));
}

ipcMain.handle('license-status', () => licenseState());
ipcMain.handle('activate-license', (_, keyText) => {
  const v = verifyKey(String(keyText || '').trim());
  if (v.ok) saveLicense(String(keyText).trim());
  return v;
});

// run pipeline.py with the engine: python + ffmpeg + node + models all ship inside
// the installer (read-only bundle). The updatable CODE (pipeline.py + skill scripts)
// runs from the writable engine mirror, so a downloaded update takes effect without
// a reinstall. The decrypted Claude key is injected as an env var only.
ipcMain.handle('generate', async (e, topic, mins, lang, voice) => {
  if (job) return { ok: false, error: 'a generation is already running' };
  if (!licenseState().licensed) return { ok: false, error: 'license required' };
  engineMod.ensureEngine();
  const P = ensureGeminiMirror();
  const E = enginePaths();
  const PIPE = E.pipeline;
  const args = [PIPE, topic, '--mins', String(mins || 5),
                '--lang', lang || 'en', '--voice', voice || 'am_michael',
                '--workdir', DATA];
  const env = pipelineEnv();
  job = spawn(P.python, args, { cwd: path.dirname(PIPE), env });
  let buffer = '';
  let mp4 = '';
  const pushLine = (text) => {
    const m = /^\[tool\] DONE\s+(.+?)\s+\(/.exec(text);
    if (m) mp4 = m[1].trim();
    emit('job-line', { text });
  };
  job.stdout.on('data', d => {
    buffer += d.toString();
    let i;
    while ((i = buffer.indexOf('\n')) >= 0) {
      pushLine(buffer.slice(0, i));
      buffer = buffer.slice(i + 1);
    }
  });
  job.stderr.on('data', d => emit('job-line', { text: d.toString(), err: true }));
  const code = await new Promise(res => job.on('close', res));
  if (buffer) pushLine(buffer);
  buffer = ''; job = null;
  const ok = code === 0;
  emit('job-done', { ok, mp4, error: ok ? null : `pipeline exited ${code}` });
  return { ok, mp4, error: ok ? null : `pipeline exited ${code}` };
});

ipcMain.handle('open-file', async (_, p) => shell.openPath(p));
ipcMain.handle('open-folder', async (_, p) => shell.openPath(p));
ipcMain.handle('stop', async () => {
  if (job) { job.kill('SIGTERM'); job = null; emit('job-done', { ok: false, error: 'stopped by user' }); }
  return true;
});
ipcMain.handle('workdir', () => DATA);

// ---- Gemini images: one-time browser login ---------------------------------
// Opens a real Chrome window (bundled node + playwright, channel: 'chrome') with
// the tool's URL so the friend logs in ONCE. The profile lives in the writable
// DATA folder, so a later "Generate" reuses the same logged-in browser.
ipcMain.handle('gemini-login', () => {
  const P = ensureGeminiMirror();
  const profile = path.join(P.geminiRoot, 'browser', 'gemini');
  fs.mkdirSync(profile, { recursive: true });
  const login = path.join(P.geminiRoot, 'setup', 'gemini-login.js');
  if (!fs.existsSync(login)) return { ok: false, why: 'login script missing in bundle' };
  const env = Object.assign({}, process.env, {
    GEMINI_PORT: process.env.GEMINI_PORT || '9223',
    GEMINI_PROFILE: profile,
  });
  // detached so the browser outlives the click; the friend closes it when done
  spawn(P.nodeExe, [login], {
    env, cwd: P.geminiRoot,
    detached: true, stdio: 'ignore', windowsHide: true,
  }).unref();
  return { ok: true };
});

// ---- Claude API key override -------------------------------------------------
// The owner can drop their own Anthropic key on this PC (written to DATA/api.key)
// and it will be used instead of the built-in baked key. No reinstall needed.
ipcMain.handle('set-claude-key', (_, keyText) => {
  const k = String(keyText || '').trim();
  if (k) {
    fs.mkdirSync(DATA, { recursive: true });
    fs.writeFileSync(path.join(DATA, 'api.key'), k, 'utf8');
  } else {
    try { fs.unlinkSync(path.join(DATA, 'api.key')); } catch {}
  }
  return { ok: true, using: k ? 'custom' : 'built-in' };
});
ipcMain.handle('claude-key-status', () => {
  const hasCustom = !!customKey();
  const blob = decryptClaudeBlob();
  return {
    custom: hasCustom,
    source: hasCustom ? 'custom (this PC)' : 'built-in (baked)',
    // only reveal the shape, never the full key, in the UI
    prefix: (hasCustom ? customKey() : blob.key).slice(0, 8),
    baseUrl: blob.base || process.env.ANTHROPIC_BASE_URL || ''
  };
});

ipcMain.handle('gemini-status', () => {
  const P = bundlePaths();
  const profile = path.join(P.geminiRoot, 'browser', 'gemini');
  // "logged in" heuristic: the profile has a Cookies file (Chrome's encrypted store)
  const loggedIn = fs.existsSync(path.join(profile, 'Cookies')) ||
    fs.existsSync(path.join(profile, 'Default', 'Cookies'));
  return { logged: loggedIn, profile };
});

// ---- Gemini sign-out / switch account -------------------------------------
// The login profile (a real Chrome profile under the writable data root) is what
// keeps Gemini "logged in". Removing it makes the next login a fresh account,
// so a friend can swap Google accounts without a reinstall. If a Gemini Chrome
// window is still open the lock files may survive the delete; the next login
// just re-signs in, so a partial delete is not fatal.
ipcMain.handle('gemini-logout', () => {
  const P = bundlePaths();
  const profile = path.join(P.geminiRoot, 'browser', 'gemini');
  try {
    if (fs.existsSync(profile)) {
      fs.rmSync(profile, { recursive: true, force: true, maxRetries: 2 });
    }
  } catch (e) {
    return { ok: false, why: String(e.message || e).slice(0, 160) };
  }
  return { ok: true };
});

// ---- in-app updater --------------------------------------------------------
// Two independent git channels, both sha256-verified:
//   engine.zip  -> DATA\engine\   (pipeline + skill scripts; next generation)
//   ui.zip      -> DATA\ui\       (mainCore/preload/index.html/etc; next launch)
// A UI update makes the thin main.js bootstrap load the mirrored core on the
// next start, so no further installer is ever needed.
ipcMain.handle('update-check', async () => {
  try { return await engineMod.checkUpdate(); }
  catch (e) { return { configured: true, error: String(e.message || e).slice(0, 160) }; }
});
ipcMain.handle('update-apply', async () => {
  if (job) return { ok: false, why: 'a generation is running -- stop it first' };
  try {
    engineMod.ensureEngine();
    const r = await engineMod.applyUpdate();
    return { ok: true, ...r };
  } catch (e) { return { ok: false, why: String(e.message || e).slice(0, 200) }; }
});
ipcMain.handle('update-host', (_, url) => {
  const u = url && String(url).trim();
  if (u) {
    fs.mkdirSync(DATA, { recursive: true });
    fs.writeFileSync(path.join(DATA, 'update-url.txt'), u);
  } else {
    try { fs.rmSync(path.join(DATA, 'update-url.txt'), { force: true }); } catch {}
  }
  return { host: engineMod.host() };
});
ipcMain.handle('update-version', () => ({
  engine: engineMod.currentVersion(),
  ui: engineMod.uiCurrentVersion(),
}));
ipcMain.handle('engine-version', () => ({ path: engineMod.ENGINE }));
// relaunch so the bootstrap picks up the freshly updated UI core
ipcMain.handle('update-restart', () => { app.relaunch(); app.quit(); return true; });

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(() => {
    try { engineMod.ensureEngine(); } catch (e) { console.error('engine mirror failed', e); }
    ensureUiStamp();
    createWindow();
  });
  app.on('window-all-closed', () => app.quit());
}

}

module.exports = { start };
