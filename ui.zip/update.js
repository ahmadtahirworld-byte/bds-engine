// Engine + UI mirrors and the in-app updater (two independent git channels).
//
// The heavy, rarely-changed engine (python, ffmpeg, node, whisper + kokoro models,
// music beds, the read-only backend bundle) ships in the ONCE-INSTALLED installer.
// Everything that changes more often travels over the owner's git repo as two
// small, sha256-verified zips -- no 1 GB reinstall, ever:
//
//   engine channel  manifest.json { engine: {...} }  ->  DATA\engine\
//       DATA\engine\pipeline.py
//       DATA\engine\doc-skill\scripts\*.py
//       DATA\engine\vox-skill\scripts\*.py
//       ... vox-skill assets -> junctions back to the bundle
//       takes effect on the NEXT generation.
//
//   ui channel      manifest.json { ui: {...} }      ->  DATA\ui\
//       DATA\ui\mainCore.js, preload.js, index.html, baked.js,
//       update.js, license_public.pem, logo.png, icon.ico, ...
//       takes effect on the NEXT launch: the thin installer main.js (the one
//       that never changes) checks for DATA\ui\mainCore.js and loads it instead
//       of the installed copy. So after one installer, the whole UI is git-driven.
//
// Manifest shape (either form is accepted; the top-level legacy form is treated
// as an engine-only manifest):
//   { "engine": { "version":4, "url":"engine.zip", "sha256":"...", "changelog":"..." },
//     "ui":     { "version":1, "url":"ui.zip",     "sha256":"...", "changelog":"..." } }
const { net } = require('electron');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');

// Update host. Precedence:
//   1. DATA/update-url.txt  -- a host the USER set in the app's "SET UPDATE HOST" field
//   2. BUILTIN_UPDATE_HOST  -- the owner bakes their stable raw base URL here at build time
//   3. UPDATE_HOST env var  -- dev override
// The host must serve, at its base, manifest.json plus whatever zips it references
// (engine.zip, ui.zip, or absolute urls). A GitHub-repo raw base
// (https://raw.githubusercontent.com/<u>/<repo>/main) is the most stable.
// The owner's git raw base: serves manifest.json, engine.zip and ui.zip.
// The app can override it at runtime (DATA/update-url.txt) if the owner ever
// moves the repo; this value only sets the default.
const BUILTIN_UPDATE_HOST = 'https://raw.githubusercontent.com/ahmadtahirworld-byte/bds-engine/main';

function sha256(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

module.exports = function setupEngine({ DATA, BACKEND, PIPELINE, python }) {
  const ENGINE = path.join(DATA, 'engine');
  const UI = path.join(DATA, 'ui');

  function host() {
    // 1) host the user set in the app wins (persisted on this PC)
    try {
      const f = path.join(DATA, 'update-url.txt');
      if (fs.existsSync(f)) {
        const u = fs.readFileSync(f, 'utf8').trim();
        if (u) return u;
      }
    } catch { /* ignore */ }
    // 2) a dev/CI env override, 3) the owner's baked default
    return process.env.UPDATE_HOST || BUILTIN_UPDATE_HOST || '';
  }

  function hostBase() { return host().replace(/\/+$/, ''); }

  // Resolve a manifest entry's url to a fetchable one (absolute, or host-relative).
  function zipUrlFor(entry) {
    const u = entry.url || '';
    if (/^https?:\/\//i.test(u)) return u;
    return hostBase() + '/' + (u || 'engine.zip');
  }

  // Accept the new {engine:{}, ui:{}} shape and the legacy top-level engine shape.
  function parseManifest(m) {
    let engine = m.engine || null;
    let ui = m.ui || null;
    if (!engine && (m.version || m.url || m.sha256)) {
      engine = { version: m.version, url: m.url, size: m.size, sha256: m.sha256, changelog: m.changelog };
    }
    return { engine, ui };
  }

  // Point the pipeline at the writable engine instead of the read-only bundle.
  function enginePaths() {
    return {
      pipeline: path.join(ENGINE, 'pipeline.py'),
      docSkill: path.join(ENGINE, 'doc-skill'),
      voxSkill: path.join(ENGINE, 'vox-skill'),
    };
  }

  // Build / refresh the engine mirror from the bundle. Code files are copied only
  // if missing (so an applied update is never clobbered); big asset folders are
  // junctioned so they are not duplicated on disk.
  function ensureEngine() {
    fs.mkdirSync(ENGINE, { recursive: true });

    // pipeline.py
    const pipeDst = path.join(ENGINE, 'pipeline.py');
    if (!fs.existsSync(pipeDst) && fs.existsSync(PIPELINE)) {
      fs.copyFileSync(PIPELINE, pipeDst);
    }

    // doc-skill (code only, small)
    const docSrc = path.join(BACKEND, 'doc-skill');
    const docDst = path.join(ENGINE, 'doc-skill');
    if (fs.existsSync(docSrc)) {
      fs.cpSync(docSrc, docDst, { recursive: true, force: false,
        filter: (s) => !s.includes('__pycache__') });
    }

    // vox-skill: scripts are real+editable, assets are junctions to the bundle
    const voxSrc = path.join(BACKEND, 'vox-skill');
    const voxDst = path.join(ENGINE, 'vox-skill');
    if (fs.existsSync(voxSrc)) {
      fs.cpSync(path.join(voxSrc, 'scripts'), path.join(voxDst, 'scripts'),
        { recursive: true, force: false,
          filter: (s) => !s.includes('__pycache__') });
      for (const name of fs.readdirSync(voxSrc)) {
        if (name === 'scripts') continue;
        const srcPath = path.join(voxSrc, name);
        const dstPath = path.join(voxDst, name);
        const st = fs.statSync(srcPath, { throwIfNoEntry: false });
        if (!st) continue;
        if (fs.existsSync(dstPath)) continue;          // already there (copy or junction)
        if (st.isDirectory()) {
          try {
            // directory JUNCTION: instant, no data copied, no admin needed
            fs.symlinkSync(srcPath, dstPath, 'junction');
          } catch {
            fs.cpSync(srcPath, dstPath, { recursive: true });  // fall back to copy
          }
        } else {
          fs.copyFileSync(srcPath, dstPath);
        }
      }
    }

    // seed the version so a fresh install reads as v1 (updates start at v2+).
    // Never overwrite an existing one (that's an update's job).
    const vFile = path.join(ENGINE, 'version.txt');
    if (!fs.existsSync(vFile)) fs.writeFileSync(vFile, '1');
  }

  function currentVersion() {
    try { return parseInt(fs.readFileSync(path.join(ENGINE, 'version.txt'), 'utf8').trim(), 10) || 0; }
    catch { return 0; }
  }
  function uiCurrentVersion() {
    // 0 means "no UI update ever applied -- the installer's own UI is in use".
    try { return parseInt(fs.readFileSync(path.join(UI, 'version.txt'), 'utf8').trim(), 10) || 0; }
    catch { return 0; }
  }

  async function fetchJson(url) {
    const res = await net.fetch(url, { timeout: 20000 });
    if (!res.ok) throw new Error('manifest HTTP ' + res.status);
    // parse the body ourselves so a leading UTF-8 BOM (some editors add one)
    // never breaks JSON.parse the way a raw res.json() would
    const text = (await res.text()).replace(/^﻿/, '');
    return JSON.parse(text);
  }

  async function downloadZip(url, outPath) {
    const res = await net.fetch(url, { timeout: 120000 });
    if (!res.ok) throw new Error('download HTTP ' + res.status);
    const buf = Buffer.from(await res.arrayBuffer());
    fs.writeFileSync(outPath, buf);
    return buf;
  }

  // Unpack over a target dir using the BUNDLED python (no extra npm deps needed).
  function unzip(zipPath, destDir) {
    const code =
      'import sys, zipfile; ' +
      'z = zipfile.ZipFile(sys.argv[1]); ' +
      'z.extractall(sys.argv[2]); z.close()';
    const r = spawn(python, ['-c', code, zipPath, destDir],
      { stdio: 'pipe', windowsHide: true });
    return new Promise((resolve, reject) => {
      let err = '';
      r.stderr.on('data', d => { err += d; });
      r.on('close', c => c === 0 ? resolve() : reject(new Error('unzip failed: ' + err.trim().slice(0, 200))));
      r.on('error', reject);
    });
  }

  function checkBlock(entry, cur) {
    if (!entry) return { present: false, current: cur, latest: 0, available: false };
    const latest = entry.version || 0;
    return {
      present: true,
      current: cur,
      latest,
      available: latest > cur,
      changelog: entry.changelog || '',
    };
  }

  async function checkUpdate() {
    const h = hostBase();
    if (!h) return { configured: false, current: currentVersion() };
    let manifest;
    try { manifest = await fetchJson(h + '/manifest.json'); }
    catch (e) { return { configured: true, error: String(e.message || e).slice(0, 120) }; }
    const { engine, ui } = parseManifest(manifest);
    const engBlock = checkBlock(engine, currentVersion());
    const uiBlock = checkBlock(ui, uiCurrentVersion());
    return {
      configured: true,
      engine: engBlock,
      ui: uiBlock,
      // convenience (engine-centric, mirrors the pre-UI-channel shape):
      current: engBlock.current,
      latest: engBlock.latest,
      available: engBlock.available || uiBlock.available,
      changelog: engBlock.changelog,
      size: (engine && engine.size) || 0,
    };
  }

  async function applyUpdate() {
    const h = hostBase();
    if (!h) throw new Error('updates not configured');
    const manifest = await fetchJson(h + '/manifest.json');
    const { engine, ui } = parseManifest(manifest);
    let engineVersion = null, uiVersion = null;

    // apply only the channels that are actually newer than what's on this PC;
    // re-applying an already-current version is a pointless re-download
    const engNewer = engine && (engine.version || 0) > currentVersion();
    const uiNewer = ui && (ui.version || 0) > uiCurrentVersion();

    if (engNewer) {
      const tmp = path.join(os.tmpdir(), 'bds-engine-' + process.pid + '.zip');
      const buf = await downloadZip(zipUrlFor(engine), tmp);
      if (engine.sha256 && sha256(buf) !== engine.sha256) {
        fs.rmSync(tmp, { force: true });
        throw new Error('engine checksum mismatch -- update rejected for safety');
      }
      await unzip(tmp, ENGINE);
      fs.rmSync(tmp, { force: true });
      fs.writeFileSync(path.join(ENGINE, 'version.txt'), String(engine.version || 1));
      // drop stale bytecode so the new source is what runs
      for (const py of ['doc-skill', 'vox-skill']) {
        fs.rmSync(path.join(ENGINE, py, 'scripts', '__pycache__'), { recursive: true, force: true });
      }
      engineVersion = engine.version;
    }

    if (uiNewer) {
      const tmp = path.join(os.tmpdir(), 'bds-ui-' + process.pid + '.zip');
      const buf = await downloadZip(zipUrlFor(ui), tmp);
      if (ui.sha256 && sha256(buf) !== ui.sha256) {
        fs.rmSync(tmp, { force: true });
        throw new Error('ui checksum mismatch -- update rejected for safety');
      }
      fs.mkdirSync(UI, { recursive: true });
      await unzip(tmp, UI);
      fs.rmSync(tmp, { force: true });
      fs.writeFileSync(path.join(UI, 'version.txt'), String(ui.version || 1));
      uiVersion = ui.version;
    }

    if (engineVersion == null && uiVersion == null) {
      // nothing newer on either channel -- fine, report as a no-op success
      return { ok: true, engineVersion: currentVersion(), uiVersion: uiCurrentVersion(),
               restartNeeded: false, alreadyCurrent: true };
    }
    return { ok: true, engineVersion, uiVersion, restartNeeded: uiVersion != null };
  }

  return {
    ENGINE,
    UI,
    enginePaths,
    ensureEngine,
    checkUpdate,
    applyUpdate,
    currentVersion,
    uiCurrentVersion,
    host,
  };
}
