const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('studio', {
  generate: (topic, mins, lang, voice) => ipcRenderer.invoke('generate', topic, mins, lang, voice),
  openFile: p => ipcRenderer.invoke('open-file', p),
  openFolder: p => ipcRenderer.invoke('open-folder', p),
  stop: () => ipcRenderer.invoke('stop'),
  workdir: () => ipcRenderer.invoke('workdir'),
  onLine: cb => ipcRenderer.on('job-line', (_, p) => cb(p)),
  onDone: cb => ipcRenderer.on('job-done', (_, p) => cb(p)),
  license: {
    status: () => ipcRenderer.invoke('license-status'),
    activate: key => ipcRenderer.invoke('activate-license', key)
  },
  gemini: {
    login: () => ipcRenderer.invoke('gemini-login'),
    logout: () => ipcRenderer.invoke('gemini-logout'),
    status: () => ipcRenderer.invoke('gemini-status')
  },
  claudeKey: {
    set: key => ipcRenderer.invoke('set-claude-key', key),
    status: () => ipcRenderer.invoke('claude-key-status')
  },
  update: {
    check: () => ipcRenderer.invoke('update-check'),
    apply: () => ipcRenderer.invoke('update-apply'),
    setHost: url => ipcRenderer.invoke('update-host', url),
    version: () => ipcRenderer.invoke('update-version'),
    restart: () => ipcRenderer.invoke('update-restart')
  }
});
